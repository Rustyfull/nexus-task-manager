import pytest
from app.core.security import security_service


def test_hash_password():
    """Test password hashing."""
    password = "secure_password_123"
    hashed = security_service.hash_password(password)
    
    assert hashed != password
    assert security_service.verify_password(password, hashed)


def test_verify_password_wrong():
    """Test wrong password verification."""
    password = "correct_password"
    hashed = security_service.hash_password(password)
    
    assert not security_service.verify_password("wrong_password", hashed)


def test_create_access_token():
    """Test access token creation."""
    data = {"sub": "123", "email": "test@example.com"}
    token = security_service.create_access_token(data)
    
    assert token is not None
    assert isinstance(token, str)
    
    # Decode and verify
    payload = security_service.decode_token(token)
    assert payload is not None
    assert payload["sub"] == "123"
    assert payload["type"] == "access"


def test_create_refresh_token():
    """Test refresh token creation."""
    data = {"sub": "123", "email": "test@example.com"}
    token = security_service.create_refresh_token(data)
    
    assert token is not None
    
    # Decode and verify
    payload = security_service.decode_token(token)
    assert payload is not None
    assert payload["type"] == "refresh"


def test_decode_invalid_token():
    """Test decoding invalid token."""
    payload = security_service.decode_token("invalid.token.here")
    assert payload is None


def test_decode_expired_token():
    """Test that expired tokens are detected."""
    from datetime import timedelta, timezone, datetime
    
    # Create a token that expires immediately
    data = {"sub": "123"}
    to_encode = data.copy()
    to_encode.update({
        "exp": datetime.now(timezone.utc) - timedelta(hours=1),
        "type": "access"
    })
    
    from jose import jwt
    from app.core.config import settings
    
    expired_token = jwt.encode(
        to_encode,
        settings.secret_key,
        algorithm=settings.algorithm
    )
    
    payload = security_service.decode_token(expired_token)
    assert payload is None
